import { Injectable, OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {

  async onModuleInit() {
    await this.$connect();
    console.log('🚀 Banco de dados conectado com sucesso via Prisma v6!');
  }

  async onModuleDestroy() {
    await this.$disconnect();
  }
}